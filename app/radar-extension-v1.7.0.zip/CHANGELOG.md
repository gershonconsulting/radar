# Radar — Sales Nav Connections — Changelog

Version lives in `manifest.json` (`"version"`), is shown in the popup (top-right), and is
stamped on every collected row via the `source` field (`radar-ext-vX.Y.Z`). Bump it in
`manifest.json` on every release and add an entry here. (Bump the source tag in
`sync-core.js` too if you want collected rows to record the new version.)

## v1.3.1 — 2026-06-19  (reconciliation)
- **Merged the GitHub `main` (v1.3.0) lineage with the local lineage** — the two had forked.
  Kept from GitHub: **background service worker** (`sync-core.js` is now the worker; `background.js`
  deprecated), **`radarLog` dashboard logging** + `getLog`/`clearLog`/`syncNow` message API,
  the **deployed hub URL**, and the **6 bridges + Europe/11-50/exclude-messaged** targeting.
  Kept from local: **new-connection notifications** (+ click-to-open), **cookie `li_at` login
  check**, the **validated lead-anchor scraper** (GitHub's `data-anonymize` selectors were the
  stale ones), and **source/bridge/category** fields in the payload.
- Popup now drives the worker via messages and shows the live `radarLog`.
- **Process rule going forward:** GitHub `main` is the single source of truth. Every agent
  (Ariel, Charles, …) branches from it and commits back — no more private local forks. Bump
  `manifest.json` on every change (patch = fix, minor = feature) so the local copy gets reloaded.

## v1.2.0 — 2026-06-17
- **Desktop notifications**: pops "{name} from {company} is a new connection of {bridge}" for
  each genuinely-new connection found (capped per run; clicking opens the LinkedIn profile).
  Adds the `notifications` permission.
- Shared "known leads" lookup (`fetchKnownLeadIds`) powers both new-lead detection and the
  resolve-skip, so profiles are never re-opened.

## v1.1.0 — 2026-06-17
- New **radar icon** (16/48/128).
- **Rebuilt scraper** against current Sales Navigator markup (no longer relies on
  `data-anonymize`/class names; anchors on `/sales/lead/` cards). Captures name, title,
  company, **location**, and the Sales Nav lead URN.
- **Public LinkedIn URL resolver**: opens each lead, reads the public `/in/` URL (required by
  Botdog). Capped at 100 profile-views/run; **skips already-resolved leads**.
- **Source column** added end to end (each bridge tagged with its origin list/network).
- Per-bridge config simplified to `{ bridge, category, source, urn }` with a shared filter
  template (CXO/Owner · France · 11–50).

## v1.0.0 — 2026-06-16
- Initial build: daily alarm + manual "Sync Now"; scrape a bridge's Sales Nav connections;
  POST to the Google Apps Script ingest endpoint → Google Sheet. (Original `data-anonymize`
  selectors — superseded in v1.1.0.)

## Backlog (likely next versions)
- Backend-driven bridge list + ICP filters (edit in the app instead of code).
- URN resolution at scale for onboarding many bridges (~150 contacts).
- Resume/region tuning, per-bridge campaign routing.
